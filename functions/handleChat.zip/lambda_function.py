import json
import boto3
import os

bedrock_agent_runtime = boto3.client('bedrock-agent-runtime')

AGENT_ID = os.getenv("AgentID")
AGENT_ALIAS_ID = os.getenv("AgentAliasID")
API_GATEWAY_ENDPOINT = os.getenv("ApiGatewayEndpoint")

api_gateway_management_api = boto3.client('apigatewaymanagementapi', endpoint_url=API_GATEWAY_ENDPOINT)

def post_to_connection(connection_id, data):
    try:
        api_gateway_management_api.post_to_connection(
            ConnectionId=connection_id,
            Data=json.dumps(data).encode('utf-8')
        )
    except api_gateway_management_api.exceptions.GoneException:
        print(f"Connection {connection_id} is no longer available.")

def lambda_handler(event, context):
    connection_id = event.get('requestContext', {}).get('connectionId')
    
    body = json.loads(event.get('body', '{}'))
    user_message = body.get('message')
    session_id = body.get('sessionId')

    if not user_message or not session_id or not connection_id:
        error_response = {'sender': 'system', 'error': 'Message, sessionId, and connectionId are required.'}
        post_to_connection(connection_id, error_response)
        return {'statusCode': 400}

    try:
        response = bedrock_agent_runtime.invoke_agent(
            agentId=AGENT_ID,
            agentAliasId=AGENT_ALIAS_ID,
            sessionId=session_id,
            inputText=user_message,
            sessionState={
            'sessionAttributes': {
                'sessionId': session_id
                }
            }
        )

        agent_response_text = ""
        for chunk in response['completion']:
            agent_response_text += chunk['chunk']['bytes'].decode('utf-8')

    except Exception as e:
        print(f"Error invoking Bedrock Agent: {e}")
        agent_response_text = "Sorry, I encountered an error. Please try again."

    message_to_user = {'sender': 'agent', 'message': agent_response_text}
    post_to_connection(connection_id, message_to_user)
    
    return {'statusCode': 200, 'body': 'Message processed.'}