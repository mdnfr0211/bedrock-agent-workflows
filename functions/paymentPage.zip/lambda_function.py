import json
import boto3
import os

eventbridge_client = boto3.client('events')
eventbridge_bus_name = os.environ['EvenbridgeBusName']

def lambda_handler(event, context):
    query_params = event.get('queryStringParameters', {})
    order_id = query_params.get('order_id')

    if not order_id:
        return {'statusCode': 400, 'body': 'order_id is required in the query string.'}

    event_payload = {
        'Source': 'com.my-ecommerce.payment',
        'DetailType': 'PaymentSuccessful',
        'Detail': json.dumps({
            'order_id': order_id,
            'status': 'SUCCESS'
        }),
        'EventBusName': eventbridge_bus_name 
    }

    try:
        response = eventbridge_client.put_events(Entries=[event_payload])
        print(response)
    except Exception as e:
        print(f"Error sending event to EventBridge: {e}")
        return {'statusCode': 500, 'body': 'Failed to process payment event.'}

    return {'statusCode': 200, 'body': 'Payment Successful! You can now close this window.'}