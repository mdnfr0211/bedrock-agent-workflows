import json
import boto3
import random
import string
import os

# DynamoDB table
dynamodb = boto3.resource('dynamodb')
orders_table = dynamodb.Table(os.getenv("OrderTable"))

def lambda_handler(event, context):
    try:
        print(f"Received event: {json.dumps(event)}")

        # Extract order_id from parameters
        parameters = event.get("parameters", [])
        order_id = None
        for param in parameters:
            if param.get("name") == "order_id":
                order_id = param.get("value")

        if not order_id:
            return _error_response(event, {"error": "order_id is required"})

        # Generate tracking number
        tracking_number = 'TRK' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

        # Update order in DynamoDB
        orders_table.update_item(
            Key={'order_id': order_id},
            UpdateExpression='SET order_status = :status, tracking_number = :tn',
            ExpressionAttributeValues={
                ':status': 'SHIPPED',
                ':tn': tracking_number
            }
        )

        # Success response
        return _success_response(event, {
            "message": "Order dispatched successfully.",
            "tracking_number": tracking_number
        })

    except Exception as e:
        print(f"Error occurred: {e}")
        import traceback
        traceback.print_exc()
        return _error_response(event, {"error": "Internal server error"})


def _success_response(event, body_dict):
    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": event.get("actionGroup"),
            "function": event.get("function"),
            "functionResponse": {
                "responseBody": {
                    "TEXT": {"body": json.dumps(body_dict)}
                }
            }
        }
    }


def _error_response(event, body_dict):
    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": event.get("actionGroup"),
            "function": event.get("function"),
            "functionResponse": {
                "responseBody": {
                    "TEXT": {"body": json.dumps(body_dict)}
                }
            }
        }
    }
