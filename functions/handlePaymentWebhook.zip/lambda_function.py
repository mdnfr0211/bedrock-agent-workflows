import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')
bedrock_agent_runtime = boto3.client('bedrock-agent-runtime')
orders_table = dynamodb.Table(os.getenv("OrderTable"))
connections_table = dynamodb.Table(os.getenv("WebSocketTable"))

AGENT_ID = os.getenv("AgentID")
AGENT_ALIAS_ID = os.getenv("AgentAliasID")
API_GATEWAY_ENDPOINT = os.getenv("ApiGatewayEndpoint")

api_gateway_management_api = boto3.client('apigatewaymanagementapi', endpoint_url=API_GATEWAY_ENDPOINT)

def post_to_connection(connection_id, data):
    try:
        api_gateway_management_api.post_to_connection(
            ConnectionId=connection_id,
            Data=json.dumps(data).encode('utf-8')
        )
    except api_gateway_management_api.exceptions.GoneException:
        print(f"Connection {connection_id} is no longer available.")
        connections_table.delete_item(Key={'connectionId': connection_id})

def lambda_handler(event, context):
    print(f"Received event: {json.dumps(event)}")

    detail = event.get('detail', {})
    order_id = detail.get('order_id')
    payment_status = detail.get('status')

    if not order_id or not payment_status == 'SUCCESS':
        print(f"Invalid payload received from EventBridge: {detail}")
        return {'statusCode': 400, 'body': 'Invalid event payload.'}

    orders_table.update_item(
        Key={'order_id': order_id},
        UpdateExpression='SET order_status = :status',
        ExpressionAttributeValues={':status': 'PAYMENT_SUCCESSFUL'}
    )

    order_item = orders_table.get_item(Key={'order_id': order_id}).get('Item')
    if not order_item or 'session_id' not in order_item:
        print(f"Error: sessionId not found for order {order_id}")
        return {'statusCode': 500, 'body': 'Internal server error.'}
    session_id = order_item['session_id']

    print(f"Session ID: {session_id}")

    try:
        response = bedrock_agent_runtime.invoke_agent(
            agentId=AGENT_ID,
            agentAliasId=AGENT_ALIAS_ID,
            sessionId=session_id,
            inputText=f"ACTION_PROMPT: Payment for order_id '{order_id}' is successful. Your next and only action is to immediately invoke the ShippingAgent to dispatch the order.",
            sessionState = {
            'promptSessionAttributes': {
                'order_id': order_id
                }
            }
        )

        agent_response_text = ""
        for chunk in response['completion']:
            agent_response_text += chunk['chunk']['bytes'].decode('utf-8')

    except Exception as e:
        print(f"Error invoking Bedrock Agent: {e}")
        agent_response_text = "There was an error processing your shipment. Please contact support."

    response = connections_table.query(
        IndexName='sessionId-index',
        KeyConditionExpression='sessionId = :sid',
        ExpressionAttributeValues={':sid': session_id}
    )
    
    connections = response.get('Items', [])
    if not connections:
        print(f"No active WebSocket connection found for session {session_id}")
        return {'statusCode': 200, 'body': 'Webhook processed, but no active client to notify.'}

    connection_id = connections[0]['connectionId']
    print(f"Connection ID: {connection_id}")
    message_to_user = {'sender': 'agent', 'message': agent_response_text}
    post_to_connection(connection_id, message_to_user)
    
    return {'statusCode': 200, 'body': 'Proactive notification sent.'}