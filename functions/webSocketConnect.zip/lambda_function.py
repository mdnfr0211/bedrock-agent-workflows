import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.getenv("WebSocketTable"))

def lambda_handler(event, context):
    connection_id = event.get('requestContext', {}).get('connectionId')
    
    query_params = event.get('queryStringParameters', {})
    session_id = query_params.get('sessionId')

    if not connection_id or not session_id:
        return {'statusCode': 400, 'body': 'connectionId and sessionId are required.'}

    table.put_item(
        Item={
            'connectionId': connection_id,
            'sessionId': session_id
        }
    )

    return {'statusCode': 200, 'body': 'Connected.'}