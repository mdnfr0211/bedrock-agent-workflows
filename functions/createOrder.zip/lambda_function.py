import json
import uuid
import boto3
import time
import os

# DynamoDB tables
dynamodb = boto3.resource('dynamodb')
products_table = dynamodb.Table(os.getenv("ProductTable"))
orders_table = dynamodb.Table(os.getenv("OrderTable"))
payment_gateway_url = os.getenv("PaymentGatewayURL")

def lambda_handler(event, context):
    try:
        print(f"Received event: {json.dumps(event)}")

        # Extract parameters
        parameters = event.get("parameters", [])
        product_id, quantity = None, None

        for param in parameters:
            if param.get("name") == "product_id":
                product_id = param.get("value")
            elif param.get("name") == "quantity":
                quantity = param.get("value")
            # elif param.get("name") == "sessionId":
            #     sessionId = param.get("value")
        
        sessionId = event["sessionAttributes"]["sessionId"]

        if not product_id or not quantity:
            return _error_response(event, {"error": "product_id and quantity are required"})

        # Step 1: Check inventory
        product_response = products_table.get_item(Key={"product_id": product_id})
        product_item = product_response.get("Item")
        if not product_item or int(product_item.get("stock_level", 0)) <= 0:
            return _error_response(event, {"error": f"Product {product_id} is out of stock"})

        # Step 2: Create order
        order_id = str(uuid.uuid4())
        orders_table.put_item(
            Item={
                "order_id": order_id,
                "product_id": product_id,
                "quantity": int(quantity),
                "session_id": sessionId,
                "order_status": "AWAITING_PAYMENT",
                "created_at": int(time.time())
            }
        )

        # Step 3: Generate payment link
        fake_payment_link = f"{payment_gateway_url}/pay?order_id={order_id}"

        # Step 4: Return both order_id and payment_link
        return _success_response(event, {
            "order_id": order_id,
            "payment_link": fake_payment_link
        })

    except Exception as e:
        print(f"Error occurred: {e}")
        import traceback
        traceback.print_exc()
        return _error_response(event, {"error": "Internal server error"})


def _success_response(event, body_dict):
    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": event.get("actionGroup"),
            "function": event.get("function"),
            "functionResponse": {
                "responseBody": {
                    "TEXT": {"body": json.dumps(body_dict)}
                }
            }
        }
    }


def _error_response(event, body_dict):
    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": event.get("actionGroup"),
            "function": event.get("function"),
            "functionResponse": {
                "responseBody": {
                    "TEXT": {"body": json.dumps(body_dict)}
                }
            }
        }
    }
